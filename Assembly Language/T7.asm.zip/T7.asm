;Task5

[org 0x0100]

var: dw 8
mov cx [var]   ; starting the counter
mov ax, 0      ; ax is the accumulator for the sum

l1:
add ax, cx
sub cx, 1
jne l1

add ax, 0x4c00
int 0x21

