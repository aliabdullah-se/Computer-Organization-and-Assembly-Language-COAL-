[org 0x0100]

jmp start

array1: dw 6, 7, 3, 9, 100, 5, 1, 50
lenArray1: dw 8

; BubbleSort(array offset, length)
; [bp+6] = array offset, [bp+4] = length
; sorts the array in place (ascending)
BubbleSort:
    push bp
    mov bp, sp
    push ax
    push cx
    push dx
    push si

    mov cx, [bp+4]          ; cx = length
    cmp cx, 1
    jbe sortDone            ; 0 or 1 element, nothing to sort
    dec cx                  ; passes = length - 1

outerLoop:
    mov si, [bp+6]          ; si = start of array
    mov dx, cx              ; comparisons in this pass

innerLoop:
    mov ax, [si]
    cmp ax, [si+2]
    jbe noSwap
    xchg ax, [si+2]         ; swap the two elements
    mov [si], ax
noSwap:
    add si, 2
    dec dx
    jnz innerLoop

    dec cx
    jnz outerLoop

sortDone:
    pop si
    pop dx
    pop cx
    pop ax
    pop bp
    ret 4

; statOfArray(array offset, length) -> min, max, median
; Stack layout inside the function:
;   [bp+4]  = length
;   [bp+6]  = array offset
;   [bp+8]  = space for min
;   [bp+10] = space for max
;   [bp+12] = space for median
statOfArray:
    push bp
    mov bp, sp
    push ax
    push bx
    push si

    push word [bp+6]        ; pass array offset
    push word [bp+4]        ; pass length
    call BubbleSort         ; array is now sorted

    mov si, [bp+6]          ; si = array start

    mov ax, [si]            ; min = first element
    mov [bp+8], ax

    mov bx, [bp+4]
    shl bx, 1               ; bx = length * 2 (bytes)
    mov ax, [si+bx-2]       ; max = last element
    mov [bp+10], ax

    mov bx, [bp+4]
    shr bx, 1               ; bx = length / 2 (middle index)
    shl bx, 1               ; convert index to bytes
    mov ax, [si+bx]         ; median = middle element
    mov [bp+12], ax

    pop si
    pop bx
    pop ax
    pop bp
    ret 4                   ; remove the 2 input parameters

start:
    push ax                 ; space for median
    push ax                 ; space for max
    push ax                 ; space for min

    mov ax, array1
    push ax                 ; array offset
    push word [lenArray1]   ; array length
    call statOfArray

    pop ax                  ; ax = min of array
    pop bx                  ; bx = max of array
    pop cx                  ; cx = median of array

    mov ax, 0x4c00
    int 21h
