[org 0x0100]

jmp start

; show: draws A at column si and B at column bx (row 0)
show:
    mov di, si
    shl di, 1
    mov word [es:di], 0x0741        ; 'A'
    mov di, bx
    shl di, 1
    mov word [es:di], 0x0742        ; 'B'
    ret

; hide: erases A and B from their current columns
hide:
    mov di, si
    shl di, 1
    mov word [es:di], 0x0720        ; space
    mov di, bx
    shl di, 1
    mov word [es:di], 0x0720
    ret

; delay: two empty nested loops
; increase the outer counter to slow down, decrease to speed up
delay:
    push cx
    push dx
    mov cx, 4               ; outer counter
outer:
    mov dx, 0xFFFF          ; inner counter
inner:
    dec dx
    jnz inner
    loop outer
    pop dx
    pop cx
    ret

start:
    mov ax, 0xb800
    mov es, ax

    ; clear the screen
    xor di, di
    mov ax, 0x0720
    mov cx, 2000
    cld
    rep stosw

    xor si, si              ; A starts at column 0
    mov bx, 79              ; B starts at column 79

forward:                    ; moving towards the center
    call show
    call delay
    call hide
    cmp si, 39              ; A at column 39, B at column 40 = center
    je backward
    inc si
    dec bx
    jmp forward

backward:                   ; moving back to the corners
    dec si
    inc bx
    call show
    call delay
    call hide
    cmp si, 0
    jne backward
    inc si                  ; start the forward trip again
    dec bx
    jmp forward
