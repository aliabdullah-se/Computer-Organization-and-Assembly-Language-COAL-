[org 0x0100]

jmp start

newline: db 13, 10, '$'

; printNumber: prints the number in ax in decimal
; followed by a new line. Preserves all registers.
printNumber:
    push ax
    push bx
    push cx
    push dx

    mov bx, 10
    xor cx, cx              ; digit counter
nextDigit:
    xor dx, dx
    div bx                  ; ax = ax / 10, dx = remainder
    add dl, '0'
    push dx                 ; save digit
    inc cx
    cmp ax, 0
    jnz nextDigit

printDigits:
    pop dx
    mov ah, 2
    int 21h                 ; print digit in dl
    loop printDigits

    mov dx, newline
    mov ah, 9
    int 21h                 ; go to next line

    pop dx
    pop cx
    pop bx
    pop ax
    ret

; printNumbers: numbers are pushed first, count is pushed last
;   [bp+4]  = count
;   [bp+6]  = number at end of stack (printed first)
;   [bp+8]  = next number, and so on
printNumbers:
    push bp
    mov bp, sp

    mov cx, [bp+4]          ; cx = how many numbers
    lea si, [bp+6]          ; si -> first number to print
    cmp cx, 0
    je finish

printLoop:
    mov ax, [si]
    call printNumber
    add si, 2
    loop printLoop

finish:
    ; clean the stack: count + all numbers, then return
    mov bx, [bp+4]
    shl bx, 1               ; bx = count * 2
    add bx, bp
    add bx, 4               ; bx -> last (first pushed) number slot
    mov ax, [bp+2]          ; return address
    mov [bx], ax            ; put return address in that slot
    mov sp, bp
    pop bp
    mov sp, bx              ; sp -> return address, everything above removed
    ret

start:
    push 134                ; first number to be printed
    push 189                ; second number to be printed
    push 156                ; third number to be printed
    push 3                  ; total numbers to be printed
    call printNumbers

    mov ax, 0x4c00
    int 21h
